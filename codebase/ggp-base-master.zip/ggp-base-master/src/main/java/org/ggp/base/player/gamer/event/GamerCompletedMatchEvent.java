package org.ggp.base.player.gamer.event;

import org.ggp.base.util.observer.Event;

public final class GamerCompletedMatchEvent extends Event
{

}

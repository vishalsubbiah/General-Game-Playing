package org.ggp.base.util.symbol.grammar;

public abstract class Symbol
{

	@Override
	public abstract String toString();

}

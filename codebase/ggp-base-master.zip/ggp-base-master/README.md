# GGP Java codebase for CS227B

This codebase is forked from the repo at ggp-org repo. It renames methods to match the notes for the Stanford CS227B course. It also includes files that allow for games with incomplete information (though this requires a bit of additional work to set up).